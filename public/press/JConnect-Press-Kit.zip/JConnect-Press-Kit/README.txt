JConnect press kit
==================

Everything in this folder may be used in articles, reviews and listings about JConnect.
Please don't alter the logo's colours or proportions.

Press contact: press.jconnect@proton.me
Website:       https://jconnect-1dsx.onrender.com
Press page:    https://jconnect-1dsx.onrender.com/press/
About:         https://jconnect-1dsx.onrender.com/about/


ONE LINE

JConnect is a remote-device app for Windows, macOS, Linux and Android with no IP addresses,
no port forwarding and no required account: install it, pair once, press Connect.


FIFTY WORDS

JConnect is remote-desktop software built on one rule: remote access should be as easy as
using a computer normally. Computers on a network find each other, pair once with a
six-digit code, and connect. Every session is end-to-end encrypted, and no account is
needed to use it at home.


A HUNDRED WORDS

JConnect is a remote-device app for Windows, macOS, Linux and Android that removes the setup
step from remote access. There are no IP addresses to find, no ports to forward, no VPN
profile to configure and no account to create: two computers on the same network discover
each other, the user pairs them once with a six-digit code, and presses Connect. Away from
home, JVPN carries the session over a relay that can only pass encrypted bytes. It also
includes SSH, Remote Desktop routing, encrypted device sync, and an Android app that turns a
television into a client. It is free during the beta.


FACTS

Product          JConnect - Just Connect
Category         Remote desktop and remote access software
Developer        Michael Davies, independent
Current version  0.1.0 beta (Android: 0.1.0 beta 2)
First released   September 2026
Price            Free during the beta
Licence          Proprietary; source not public
Platforms        Windows 10 and 11 (64-bit), macOS 13+ (Apple silicon and Intel),
                 Linux x86-64 (.deb, AppImage), Android 8.0+, Android TV and Google TV,
                 plus any modern browser


STATUS

JConnect is an early beta. The Windows build is not code-signed and the macOS build is not
notarized, so both warn on first run. The Android app is not on Google Play. Linux machines
can be controlled in X11 sessions only.


NAME

Write it JConnect: one word, capital J, capital C.